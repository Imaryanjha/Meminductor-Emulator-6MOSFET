import numpy as np
import matplotlib.pyplot as plt

# Read the output file
with open('mem_final.txt', 'r') as f:
    lines = f.readlines()

# Find data section
data_start = 0
for i, line in enumerate(lines):
    if 'Index' in line and 'time' in line:
        data_start = i + 2
        break

# Parse data
data = []
for line in lines[data_start:]:
    if line.strip() and not line.startswith('----') and 'Index' not in line:
        try:
            values = line.strip().split()
            if len(values) >= 5:
                # Columns: Index, time, v(vin_sense), vsense#branch, v(x)
                data.append([
                    float(values[1]),  # time
                    float(values[2]),  # v(vin_sense)
                    float(values[3]),  # current
                    float(values[4])   # v(x)
                ])
        except:
            pass

if data:
    data = np.array(data)
    print(f"Data shape: {data.shape}")
    print(f"First 5 rows: {data[:5]}")
    
    time = data[:, 0]
    v_in = data[:, 1]
    i_in = data[:, 2]
    
    print(f"\nV_in range: {v_in.min():.4f} to {v_in.max():.4f} V")
    print(f"I_in range: {i_in.min():.4e} to {i_in.max():.4e} A")
    
    # Calculate flux (integral of voltage)
    dt = time[1] - time[0] if len(time) > 1 else 1e-9
    flux = np.cumsum(v_in) * dt
    
    # Scale for plotting
    flux_uwb = flux * 1e6      # V·s to μWb
    current_na = i_in * 1e9    # A to nA (since current is pA range)
    
    print(f"\nFlux range: {flux_uwb.min():.4f} to {flux_uwb.max():.4f} μWb")
    print(f"Current range: {current_na.min():.4f} to {current_na.max():.4f} nA")
    
    # Plot Pinched Hysteresis Loop
    plt.figure(figsize=(8, 6))
    plt.plot(flux_uwb, current_na, 'b-', linewidth=1.5)
    plt.xlabel('Flux φ (μWb)', fontsize=12)
    plt.ylabel('Current I (nA)', fontsize=12)
    plt.title('Pinched Hysteresis Loop @ 10 kHz', fontsize=14, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.axhline(0, color='black', linewidth=0.5)
    plt.axvline(0, color='black', linewidth=0.5)
    
    plt.tight_layout()
    plt.savefig('phl_10khz_corrected.png', dpi=150)
    plt.show()
    print("\nPlot saved as phl_10khz_corrected.png")
else:
    print("No data found")
