import numpy as np
import matplotlib.pyplot as plt

# Read the output file
with open('mem_final.txt', 'r') as f:
    lines = f.readlines()

# Find data section
data_start = 0
for i, line in enumerate(lines):
    if 'Index' in line and 'time' in line:
        data_start = i + 2
        break

# Parse data
data = []
for line in lines[data_start:]:
    if line.strip() and not line.startswith('----') and 'Index' not in line:
        try:
            values = line.strip().split()
            if len(values) >= 4:
                data.append([float(x) for x in values[:4]])
        except:
            pass

if data:
    data = np.array(data)
    print(f"Data shape: {data.shape}")
    
    time = data[:, 1]      # time
    v_in = data[:, 2]      # v(vin_sense)
    i_in = data[:, 3]      # vsense#branch (current)
    
    print(f"V_in range: {v_in.min():.4f} to {v_in.max():.4f} V")
    print(f"I_in range: {i_in.min():.4e} to {i_in.max():.4e} A")
    
    # Calculate flux (integral of voltage)
    dt = time[1] - time[0]
    flux = np.cumsum(v_in) * dt
    
    # Scale for better visualization
    flux_uwb = flux * 1e6      # V·s to μWb
    current_ua = i_in * 1e6    # A to μA
    
    print(f"Flux range: {flux_uwb.min():.4f} to {flux_uwb.max():.4f} μWb")
    print(f"Current range: {current_ua.min():.4f} to {current_ua.max():.4f} μA")
    
    # Plot Pinched Hysteresis Loop
    plt.figure(figsize=(8, 6))
    plt.plot(flux_uwb, current_ua, 'b-', linewidth=1.5)
    plt.xlabel('Flux φ (μWb)', fontsize=12)
    plt.ylabel('Current I (μA)', fontsize=12)
    plt.title('Pinched Hysteresis Loop @ 10 kHz', fontsize=14, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.axhline(0, color='black', linewidth=0.5)
    plt.axvline(0, color='black', linewidth=0.5)
    
    # Set limits to see the loop clearly
    plt.xlim(-0.2, 0.2)
    plt.ylim(-0.015, 0.015)
    
    plt.tight_layout()
    plt.savefig('phl_final.png', dpi=150)
    plt.show()
    print("Plot saved as phl_final.png")
else:
    print("No data found")
